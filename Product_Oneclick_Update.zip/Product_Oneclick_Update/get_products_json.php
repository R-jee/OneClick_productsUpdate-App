<?php
header('Access-Control-Allow-Origin: *');
// header('Content-Security-Policy: frame-ancestors *');

include('./inc/database.php');

// echo $shop;
// echo $host_shop;


$products = shopify_call($token, $host_shop, "/admin/api/2021-07/products.json", array(), 'GET');
$products_pre = ($products['response']) ;
$products = json_decode($products['response'], JSON_PRETTY_PRINT);


// echo ("<pre>");
// print_r(  json_encode( $products['products'] ));
// echo ("</pre>");
// $product_json = json_encode($products, true);
// $product_json = serialize( json_encode( $products['products'])  );

// print_r("<pre>");
// print_r( ($product_json) );
// print_r("</pre>");

// print_r(($products_pre));


$product_json =  $products_pre;

$product_titles = array();
$product_ids = array();

foreach ($products as $key => $product) {
    foreach ($product as $key => $value) {
        // print_r($value['title'] . "<br>");
        array_push($product_titles, $value['title']);
    }
}
// print_r("<pre>");
// $product_titles = json_encode($product_titles, true);
$product_titles = serialize($product_titles);
// $product_titles = serialize($product_titles);
// print_r( $product_titles );
// print_r("</pre>");
// print_r(json_decode($product_titles, true));

foreach ($products as $key => $product) {
    foreach ($product as $key => $value) {
        // print_r(htmlToPlainText($value['body_html']) . "<br> %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        // array_push($product_ids, $value['body_html']);
        $html_BODY = $value['body_html'] ;
        $html_BODY2 = (htmlToPlainText($html_BODY)) ;
        // echo htmlToPlainText($html_BODY)." %%%%%%%%%%%% <br>";
        $start = (strpos( trim($html_BODY2) ,"Model No:") );
        // echo $start. "--";
        $end =  (strpos( $html_BODY2 ,"EAN:"));
        // echo $end. " : ";
        $before_res_str = (substr( htmlToPlainText($html_BODY2) ,  $start+9  ,  $end  ));
        // $res_string =   substr($before_res_str , 0, strrpos($before_res_str, ' '));
        // echo ( $before_res_str ."<br>");
        // echo trim(substr(  $before_res_str ,  0  ,  (strpos( $before_res_str ,"EAN:")) ) , 'o:')   ."<br>" ;
        
        // echo (strpos(htmlToPlainText($html_BODY),"Model No:"))." %%%%%%%%%%%% <br>";
        // echo (strpos(htmlToPlainText($html_BODY),"EAN:"))." %%%%%%%%%%%% <br>";
        // $html_BODY2 = htmlToPlainText($value['body_html'] );
        array_push( $product_ids,    trim(substr(  $before_res_str ,  0  ,  (strpos( $before_res_str ,"EAN:")) ) , 'o:')  );
    } 
}



// $product_ids = json_encode($product_ids, true);
$product_ids = serialize($product_ids);
// print_r($product_ids );

$stmt1 = $pdo->prepare("SELECT `shop_url` FROM `product_json` WHERE `shop_url` =?  ");
$stmt1->execute([$shop]);
$shop_get = $stmt1->fetch();

// echo $shop_get['shop_url'];

// print_r( $prod_json );
// echo( $prod_json );


$log_json =  fopen("./files/".$shop. "_productsJSON.json", "w") or die("Can not open or create this file.");

$JSON_FILE_PRODUCTS = Domain_URL_ . "/files/" .$shop. "_productsJSON.json";
if (file_exists("./files/" .$shop. "_productsJSON.json")) {
    fputs($log_json, PHP_EOL . $product_json);
} else {
    fputs($log_json,  $product_json);
}
fclose($log_json);




if ($shop_get['shop_url'] != null) {
    $sql = "UPDATE `product_json` SET `productjson_file` = '". $JSON_FILE_PRODUCTS ."',`product_titles` = '". $product_titles ."', `product_ids` = '". $product_ids . "' WHERE `shop_url` = '". $shop ."' ";
    // $statement = $pdo->prepare($sql);
    // $statement->execute();
}elseif($shop_get['shop_url'] == null ){
//     echo 'Not empty';
//     //      UPDATE `product_json` SET `id`=[value-1],`shop_url`=[value-2],`productjson_file`=[value-3],`product_titles`=[value-4],`product_ids`=[value-5],`date`=[value-6] WHERE 1
        $sql = "INSERT INTO `product_json` ( `shop_url`, `productjson_file`, `product_titles`, `product_ids`) VALUES ('" . $shop . "' , '"  . $JSON_FILE_PRODUCTS . "' , '" . $product_titles . "' , '" . $product_ids . "')";
//     $statement = $pdo->prepare($sql);
//     $statement->execute();
}




///////////////////////////////////////////////
if (mysqli_query($db, $sql)) {
        // echo "Records inserted successfully.";
} else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
// Close connection
mysqli_close($link);
/////////////////////////////////////////////


$log =  fopen("./files/".$shop . "_productsJSON.json", "w") or die("Can not open or create this file.");

if (file_exists("./files/".$shop. "_productsJSON.json")) {
    fputs($log, PHP_EOL . $product_json);
} else {
    fputs($log,  $product_json);
}
fclose($log);


?>


<?php 
    function plainText($text)
    {
        $text = strip_tags($text, '<br><p><li>');
        $text = preg_replace ('/<[^>]*>/', PHP_EOL, $text);
    
        return $text;
    }

    function htmlToPlainText($str)
{
    $str = str_replace('&nbsp;', ' ', $str);
    $str = str_replace('<br>;', '', $str);
    $str = html_entity_decode($str, ENT_QUOTES | ENT_COMPAT , 'UTF-8');
    $str = html_entity_decode($str, ENT_HTML5, 'UTF-8');
    $str = html_entity_decode($str);
    $str = htmlspecialchars_decode($str);
    $str = strip_tags($str);

    return $str;
}


?>