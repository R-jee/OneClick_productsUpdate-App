<?php
// header('Access-Control-Allow-Origin: *');
// header('Content-Security-Policy: frame-ancestors *');

include_once('./inc/database.php');
include_once('./inc/functions.php');

$products = shopify_call($token, $host_shop, "/admin/api/2021-07/products.json", array(), 'GET');
$products = json_decode($products['response'], JSON_PRETTY_PRINT);
// print_r("<pre>");
// print_r( $products );
// print_r("</pre>");

?>

<div class=".table-responsive" >
    <form method="POST" action="productDataUpdate__process.php">
        <input type="submit" class="btn btn-outline-primary" id="productsUpdate_btn" value="Submit" > 
        <button class="btn btn-primary" type="button" id="productsUpdate_btn_spin" disabled>
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            <span class="sr-only">Saving...</span>
        </button>
        <div>
            <span id="discount-load"></span>
        </div>
        <table class="table table-hover">
            <thead style="background-color: #DC143C; color:white;" class="main-table-head">
                <tr class="main-table-heading__">
                    <th scope="col"># </th>
                    <th scope="col">ID</th>
                    <th scope="col">Title</th>
                    <th scope="col">Prices</th>
                </tr>
            </thead>
            <tbody class="" id="all_product_table_body">
                <?php
                if (!empty($form_data['product_array_for_storing'])) {
                    $product_array_for_storing__data = unserialize($form_data['product_array_for_storing']);
                    $product_array_for_storing__data_array = array();
                    foreach ($product_array_for_storing__data as $key => $val_arrdata) {
                        array_push($product_array_for_storing__data_array, $val_arrdata['val']);
                    }
                }
                // print_r($product_array_for_storing__data_array);
                // array(
                //     'check_box_id' => '',
                //     'check_box_checked' => false,
                //     'id'     => '',
                //     'title'  => '',
                //     'handle' => '',
                //     'image'  => '',
                // );
                $product_array_for_storing = [];

                foreach ($products as $m_key => $product) :
                    foreach ($product as $key => $value) :
                        print_r(($value['presentment_prices']));

                        // echo '<br>';
                ?>
                        <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
                        <tr>
                            <th scope="row"><?php echo $key + 1; ?></th>
                            <td><?php echo $value['id']; ?></td>
                            <td><?php echo $value['title']; ?></td>
                            <td><?php $Prod_variants = $value['variants'];  ?>
                                <div class="accordion accordion-flush" id="accordionFlush_variants_<?php echo $key + 1; ?>">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="accordionFlush-variants-heading-<?php echo $key + 1; ?>">
                                            <button class="accordion-button collapsed btn btn-outline-info " type="button" data-bs-toggle="collapse" data-bs-target="#accordion-flush-vatriants-collapse-<?php echo $key + 1; ?>" aria-expanded="false" aria-controls="accordion-flush-vatriants-collapse-<?php echo $key + 1; ?>">
                                                Show/Hide
                                            </button>
                                        </h2>

                                        <div id="accordion-flush-vatriants-collapse-<?php echo $key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionFlush-variants-heading-<?php echo $key + 1; ?>" data-bs-parent="#accordionFlush_variants_<?php echo $key + 1; ?>">
                                            <div class="accordion-body">
                                                <!-- //// -->
                                                <div id="accordion-flush-vatriants-collapse-<?php echo $key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionFlush-variants-heading-<?php echo $key + 1; ?>" data-bs-parent="#accordionFlush_variants_<?php echo $key + 1; ?>">
                                                    <div class="accordion-body">
                                                        <div class="container wrap" style="overflow: auto; height:100%;">
                                                            <table class="table table-hover">
                                                                <thead style="background-color: #DC143C; color:white;" class="table-dark">
                                                                    <tr>
                                                                        <th scope="col"># </th>
                                                                        <th scope="col">Varient id</th>
                                                                        <th scope="col">Product id</th>
                                                                        <th scope="col">Title</th>
                                                                        <th scope="col">Price</th>


                                                                    </tr>
                                                                </thead>
                                                                <tbody class="" id="all_product_variants_table_body">
                                                                    <?php
                                                                    foreach ($Prod_variants as $variant_value_key => $variant_value) {
                                                                    ?>
                                                                        <tr>
                                                                            <td><?php echo $variant_value_key + 1; ?></td>
                                                                            <td><?php echo $variant_value['id']; ?></td>
                                                                            <td><?php echo $variant_value['product_id']; ?></td>
                                                                            <td><?php echo $variant_value['title']; ?></td>
                                                                            <td>
                                                                                <input type="text" style="width: 100px;" class="form-control form-control-sm product-price" name="price_<?php echo $variant_value['product_id'] . '-' . $variant_value['id']; ?>" id="<?php echo $variant_value['product_id'] . '-' . $variant_value['id']; ?>" placeholder="price" value="<?php echo $variant_value['price']; ?>">
                                                                                <input type="hidden" style="width: 100px;" class="form-control form-control-sm product-price-hidden" name="hiddenprice_<?php echo $variant_value['product_id'] . '-' . $variant_value['id']; ?>" id="hidden_<?php echo $variant_value['product_id'] . '-' . $variant_value['id']; ?>" placeholder="price" value="<?php echo $variant_value['price']; ?>">

                                                                            </td>


                                                                        </tr>
                                                                    <?php

                                                                    }
                                                                    ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- //// -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </td>


                            <!-- 
                        
                        <td>
                        <?php /* 
                        print_r(($value['variants'][0])['price']); ?></td>
                        <?php
                        $images = shopify_call($token, $host_shop, "/admin/api/2021-04/products/" . $value['id'] . "/images.json", array(), 'GET');
                        $images = json_decode($images['response'], JSON_PRETTY_PRINT);
                        //  print_r($images);
                        ?>
                        <td><img src="<?php if($images['images'][0]['src'] != null){echo $images['images'][0]['src'];} else{echo "https://dummyimage.com/600x400/ebe4eb/a86d8e";} ?>" style="width: 30px; height:30px;" class="img-fluid" alt="<?php echo $value['handle'];  
                        */
                        ?>"></td>
                     -->

                        </tr>
                <?php
                        array_push(
                            $product_array_for_storing,
                            array(
                                'check_box_id' => "discount_app_products" . ($key + 1),
                                'id'     => $value['id'],
                            )
                        );
                    endforeach;
                endforeach;

                ?>
            </tbody>
        </table>
        
    </form>
    <style>
        tr.main-table-heading__ {
            font-size: 12px;
            padding: 3px 3px;
            padding-bottom: 0px;
        }

        thead.main-table-head {
            vertical-align: center;
            white-space: nowrap;
        }

        tbody#all_product_table_body {
            font-size: 12px;
            white-space: nowrap;
            text-align: inherit;
        }

        button.accordion-button.btn.btn-outline-info.collapsed {
            padding: 2px 11px;
            margin: 0px 0px;
            border: 1px solid gray !important;
            border-radius: 3px !important;
            font-size: 12px;
        }

        button.accordion-button.btn.btn-outline-info {
            padding: 2px 6px;
            font-size: 12px;
        }

        .accordion-body {
            padding: 0.5rem 0.5rem;
        }


        .thumbnail_image {
            transition: 0.5s ease-in-out;
        }

        .thumbnail_image:hover {
            position: relative;
            width: 120px;
            height: auto;
            display: block;
            z-index: 999;

        }
    </style>

    <script>
        // console.log( jQuery('.product-price') );
        document.getElementById("productsUpdate_btn_spin").style.display = "none";

        var fruits = $('.product-price');
        // console.log(fruits[0]['id']);
        var hidden_prod = document.getElementById('hidden_'+fruits[0]['id']);
        // console.log(hidden_prod);

        var text = "";
        var product_IDs = [];
        var productVarients_IDs = [];
        var productPrices = [];
        var hidden_productPrices = [];

        var Prod_DATA  = [];
        for (let i = 0; i < fruits.length; i++) {
        // text += fruits[i]['id'] + "\n";
        // console.log( ((fruits[i]['id']).split('-'))[0]  );
        product_IDs.push((((fruits[i]['id']).split('-'))[0]));
        productVarients_IDs.push((((fruits[i]['id']).split('-'))[1]));
        productPrices.push( jQuery(  '#'+(((fruits[i]['id']).split('-'))[0])+'-'+(((fruits[i]['id']).split('-'))[1])  ).prop('value') );
        hidden_productPrices.push( jQuery(  '#hidden_'+(((fruits[i]['id']).split('-'))[0])+'-'+(((fruits[i]['id']).split('-'))[1])  ).prop('value') );

        }

        // console.log( jQuery('#'+product_IDs[0]+'-'+productVarients_IDs[0]).val() );
        // console.log( productPrices[0] );
        // console.log(productVarients_IDs);
        for (let i = 0; i < fruits.length; i++) {
            Prod_DATA.push( {p_ID: product_IDs[i], V_ID: productVarients_IDs[i], price: productPrices[i], productPrice_hidden :hidden_productPrices[i] } );
        }


        for (let j = 0; j < fruits.length; j++) {
            $( "#"+fruits[j]['id'] ).change(function() {
                product_IDs.length = 0;
                productVarients_IDs.length = 0;
                productPrices.length = 0;
                hidden_productPrices.length = 0;
                Prod_DATA.length = 0;

                var fruits = $('.product-price');
                for (let i = 0; i < fruits.length; i++) {
                // text += fruits[i]['id'] + "\n";
                // console.log( ((fruits[i]['id']).split('-'))[0]  );
                product_IDs.push((((fruits[i]['id']).split('-'))[0]));
                productVarients_IDs.push((((fruits[i]['id']).split('-'))[1]));
                productPrices.push( jQuery(  '#'+(((fruits[i]['id']).split('-'))[0])+'-'+(((fruits[i]['id']).split('-'))[1])  ).prop('value') );
                hidden_productPrices.push( jQuery(  '#hidden_'+(((fruits[i]['id']).split('-'))[0])+'-'+(((fruits[i]['id']).split('-'))[1])  ).prop('value') );

                }

                // console.log( jQuery('#'+product_IDs[0]+'-'+productVarients_IDs[0]).val() );
                // console.log( productPrices[0] );
                // console.log(productVarients_IDs);
                for (let i = 0; i < fruits.length; i++) {
                    Prod_DATA.push( {p_ID: product_IDs[i], V_ID: productVarients_IDs[i], price: productPrices[i], Price_hidden :hidden_productPrices[i] } );
                }
            });
        }
        // for (let i = 0; i < fruits.length; i++) {
        // // text += fruits[i]['id'] + "\n";
        // // console.log( ((fruits[i]['id']).split('-'))[0]  );
        // product_IDs.push((((fruits[i]['id']).split('-'))[0]));
        // productVarients_IDs.push((((fruits[i]['id']).split('-'))[1]));
        // productPrices.push( jQuery(  '#'+(((fruits[i]['id']).split('-'))[0])+'-'+(((fruits[i]['id']).split('-'))[1])  ).val() );

        // }

        // // console.log( jQuery('#'+product_IDs[0]+'-'+productVarients_IDs[0]).val() );
        // // console.log( productPrices[0] );
        // // console.log(productVarients_IDs);
        // for (let i = 0; i < fruits.length; i++) {
        //     Prod_DATA.push( {p_ID: product_IDs[i], V_ID: productVarients_IDs[i], price: productPrices[i] } );
        // }
        

        // console.log(Prod_DATA);

        $("#productsUpdate_btn").click(function(e) {
            e.preventDefault();
            // $("#discount-load").html(' <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> <span class="sr-only">Saving...</span>');
            document.getElementById("productsUpdate_btn").style.display = "none";
            document.getElementById("productsUpdate_btn_spin").style.display = "initial";

            jQuery.ajax({
                type: "POST",
                url: "productDataUpdate__process.php",
                data: {
                    shop         : '<?php echo $host_shop; ?>',
                //  token        : '<?php // echo $token; ?>',
                //  product_ids  : product_IDs,
                //  Varients_ids : productVarients_IDs,
                    data         : Prod_DATA
                },
                success: function(result) {
                    // alert(result);
                    // alert( JSON.parse(result));
                    //	$("#discount-load").html("");
                    document.getElementById("productsUpdate_btn").style.display = "initial";
                    document.getElementById("productsUpdate_btn_spin").style.display = "none";
                        //alert(data); // show response from the php script.
                    customAlert("Successfully Updated!", "1200");
                },
                error: function(result) {
                    alert('error');
                }
            });
        });

        function customAlert(msg, duration) {
                var styler = document.createElement("div");
                styler.innerHTML = '<div class ="alert alert-success"role = "alert" >' + msg + '</div>';
                styler.setAttribute("style", "width:auto;height:50px; padding:0px; margin-top:10px;");
                setTimeout(function() {
                    styler.parentNode.removeChild(styler);
                }, duration);
                document.body.prepend(styler);
            }

    </script>

</div>