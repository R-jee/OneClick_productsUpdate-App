<?php

$selected_theme_id = null;

$Get_Theme = shopify_call($token, $host_shop, "/admin/api/2021-07/themes.json", array(), 'GET');
$Get_Theme = json_decode($Get_Theme['response'], JSON_PRETTY_PRINT);

// $Get_Theme_type = $Get_Theme['recurring_application_charge']['name'];
// print_r($Get_Theme['themes'][0]);
foreach ($Get_Theme['themes'] as $key => $sel_theme) {
    if ($sel_theme['role'] == 'main') {
        $selected_theme_id = $sel_theme;
    }
}

// print_r($selected_theme_id["id"]);


/////////////////////////////////////////////   Put  Assets -- Creating Creating  CountDown.JS file in Store....
$array = array(
    'asset' => array(
        "key" => "assets/countdown.js",
        "value" => 'const $=e=>document.querySelector(e),countdown=function(e){const t=$(e.target).getAttribute("data-date").split("-"),r=parseInt(t[0]),n=parseInt(t[1]),a=parseInt(t[2]);let o,d,i=$(e.target).getAttribute("data-time");null!=i&&(i=i.split(":"),o=parseInt(i[0]),d=parseInt(i[1]));(new Date).getFullYear();let g=new Date;g.getDate(),g.getMonth(),g.getFullYear(),g.getHours(),g.getMinutes();const u=new Date(a,n-1,r,o,d,0,0).getTime();$(e.target+" .day .word").innerHTML=e.dayWord,$(e.target+" .hour .word").innerHTML=e.hourWord,$(e.target+" .min .word").innerHTML=e.minWord,$(e.target+" .sec .word").innerHTML=e.secWord;const s=()=>{const t=(new Date).getTime(),r=u-t,n=Math.floor(r/864e5),a=Math.floor(r%864e5/36e5),o=Math.floor(r%36e5/6e4),d=Math.floor(r%6e4/1e3);requestAnimationFrame(s),$(e.target+" .day .num").innerHTML=addZero(n),$(e.target+" .hour .num").innerHTML=addZero(a),$(e.target+" .min .num").innerHTML=addZero(o),$(e.target+" .sec .num").innerHTML=addZero(d),r<0&&($(".countdown").innerHTML="EXPIRED")};s()},addZero=e=>e<10&&e>=0?"0"+e:e;'
    )
);

$Put_selectedTheme_Assets = shopify_call($token, $host_shop, "/admin/api/2021-07/themes/" . $selected_theme_id["id"] . " /assets.json", $array, 'PUT');
$Put_selectedTheme_Assets = json_decode($Put_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
/////////////////////////////////////////////   Get  Assets
$Get_selectedTheme_Assets = shopify_call($token, $host_shop, "/admin/api/2021-07/themes/" . $selected_theme_id["id"] . "/assets.json", array('asset' => array("key" => 'layout/theme.liquid')), 'GET');
$Get_selectedTheme_Assets = json_decode($Get_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
// echo '<pre><html>';
// print_r($Get_selectedTheme_Assets['asset']['value']); 
// echo '</html></pre>';

if (strpos($Get_selectedTheme_Assets['asset']['value'], "{{ 'countdown.js'  | asset_url | script_tag }}") !== false) {
    // echo "CountDown.JS file Found in Store!";
} else {
    $string_html_data_value = substr_replace(
        $Get_selectedTheme_Assets['asset']['value'],
        "{{ 'countdown.js'  | asset_url | script_tag }}" . PHP_EOL,
        strpos($Get_selectedTheme_Assets['asset']['value'], '</head>'),
        0
    );

    $assets_countDownJS_link = array(
        "asset" => array(
            "key" => "layout/theme.liquid",
            "value" =>  $string_html_data_value,
        )
    );

    // /admin/api/2021-07/themes/828155753/assets.json
    $Set_selectedTheme_Assets = shopify_call($token, $host_shop, "/admin/api/2021-07/themes/" . $selected_theme_id["id"] . "/assets.json", $assets_countDownJS_link, 'PUT');
    $Set_selectedTheme_Assets = json_decode($Set_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);

    // print_r($Set_selectedTheme_Assets);

}
/////////////////

/////////////////////////////////////////////   Put  Assets -- Creating Creating  CountDown.CSS file in Store....
$array = array(
    'asset' => array(
        "key" => "assets/countdown.css",
        "value" => '<link href="https://fonts.googleapis.com/css?family=Abel|Abril+Fatface|Acme|Alegreya|Alegreya+Sans|Anton|Archivo|Archivo+Black|Archivo+Narrow|Arimo|Arvo|Asap|Asap+Condensed|Bitter|Bowlby+One+SC|Bree+Serif|Cabin|Cairo|Catamaran|Crete+Round|Crimson+Text|Cuprum|Dancing+Script|Dosis|Droid+Sans|Droid+Serif|EB+Garamond|Exo|Exo+2|Faustina|Fira+Sans|Fjalla+One|Francois+One|Gloria+Hallelujah|Hind|Inconsolata|Indie+Flower|Josefin+Sans|Julee|Karla|Lato|Libre+Baskerville|Libre+Franklin|Lobster|Lora|Mada|Manuale|Maven+Pro|Merriweather|Merriweather+Sans|Montserrat|Montserrat+Subrayada|Mukta+Vaani|Muli|Noto+Sans|Noto+Serif|Nunito|Open+Sans|Open+Sans+Condensed:300|Oswald|Oxygen|PT+Sans|PT+Sans+Caption|PT+Sans+Narrow|PT+Serif|Pacifico|Passion+One|Pathway+Gothic+One|Play|Playfair+Display|Poppins|Questrial|Quicksand|Raleway|Roboto|Roboto+Condensed|Roboto+Mono|Roboto+Slab|Ropa+Sans|Rubik|Saira|Saira+Condensed|Saira+Extra+Condensed|Saira+Semi+Condensed|Sedgwick+Ave|Sedgwick+Ave+Display|Shadows+Into+Light|Signika|Slabo+27px|Source+Code+Pro|Source+Sans+Pro|Spectral|Titillium+Web|Ubuntu|Ubuntu+Condensed|Varela+Round|Vollkorn|Work+Sans|Yanone+Kaffeesatz|Zilla+Slab|Zilla+Slab+Highlight" rel="stylesheet">'
    )
);

$Put_selectedTheme_Assets = shopify_call($token, $host_shop, "/admin/api/2021-07/themes/" . $selected_theme_id["id"] . " /assets.json", $array, 'PUT');
$Put_selectedTheme_Assets = json_decode($Put_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
/////////////////////////////////////////////   Get  Assets
$Get_selectedTheme_Assets = shopify_call($token, $host_shop, "/admin/api/2021-07/themes/" . $selected_theme_id["id"] . "/assets.json", array('asset' => array("key" => 'layout/theme.liquid')), 'GET');
$Get_selectedTheme_Assets = json_decode($Get_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
// echo '<pre><html>';
// print_r($Get_selectedTheme_Assets['asset']['value']); 
// echo '</html></pre>';

if (strpos($Get_selectedTheme_Assets['asset']['value'], "{{ 'countdown.css'  | asset_url | stylesheet_tag }}") !== false) {
    // echo "CountDown.CSS file Found in Store!";
} else {
    $string_html_data_value = substr_replace(
        $Get_selectedTheme_Assets['asset']['value'],
        "{{ 'countdown.css'  | asset_url | stylesheet_tag }}" . PHP_EOL,
        strpos($Get_selectedTheme_Assets['asset']['value'], '</head>'),
        0
    );
    
    $assets_countDownCSS_link = array(
        "asset" => array(
            "key" => "layout/theme.liquid",
            "value" =>  $string_html_data_value,
        )
    );

    // /admin/api/2021-07/themes/828155753/assets.json
    $Set_selectedTheme_Assets = shopify_call($token, $host_shop, "/admin/api/2021-07/themes/" . $selected_theme_id["id"] . "/assets.json", $assets_countDownCSS_link, 'PUT');
    $Set_selectedTheme_Assets = json_decode($Set_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
    
    // print_r($Set_selectedTheme_Assets);
    
}
/////////////////


/////////////////////////////////////////////   Put  Sections --  Creating  countdown-bar.liquid in Store....
$array = array(
    'asset' => array(
        "key" => "sections/countdown-bar.liquid",
        "value" => file_get_contents("countdown.txt")
    )
);

$Put_selectedTheme_Assets = shopify_call($token, $host_shop, "/admin/api/2021-07/themes/" . $selected_theme_id["id"] . " /assets.json", $array, 'PUT');
$Put_selectedTheme_Assets = json_decode($Put_selectedTheme_Assets['response'], JSON_PRETTY_PRINT);
// print_r($Put_selectedTheme_Assets);

