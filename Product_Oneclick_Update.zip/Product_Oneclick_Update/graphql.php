<?php


$query = array('query' => "{
    products(first:10){
        edges{
            node{
                id
                title
                tags
            }
        }
    }
}");

$gql = shopify_graphQL_call($token, $host_shop, $query);
echo print_r($gql['response']);
