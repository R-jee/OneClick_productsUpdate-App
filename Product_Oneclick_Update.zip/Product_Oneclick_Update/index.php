<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Lobster|Josefin+Sans|Shadows+Into+Light|Pacifico|Amatic+SC:700|Orbitron:400,900|Rokkitt|Righteous|Dancing+Script:700|Bangers|Chewy|Sigmar+One|Architects+Daughter|Abril+Fatface|Covered+By+Your+Grace|Kaushan+Script|Gloria+Hallelujah|Satisfy|Lobster+Two:700|Comfortaa:700|Cinzel|Courgette' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Lobster|Josefin+Sans|Shadows+Into+Light|Pacifico|Amatic+SC:700|Orbitron:400,900|Rokkitt|Righteous|Dancing+Script:700|Bangers|Chewy|Sigmar+One|Architects+Daughter|Abril+Fatface|Covered+By+Your+Grace|Kaushan+Script|Gloria+Hallelujah|Satisfy|Lobster+Two:700|Comfortaa:700|Cinzel|Courgette' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="./css/custom_app.css">

    <title>Document</title>

</head>

<body>

    <div class="container pt-3">
        <span id="discount-load"></span>

        <?php

        include_once("inc/functions.php");
        include_once("inc/database.php");
        include_once("header.php");
        ?>

        <!-- <div class="container wrap">
            <div class="" id="log"></div> -->
        <div class="container">
            <div class="row ">
                <?php

                $webhook_count = shopify_call($token, $host_shop, "/admin/api/2021-07/webhooks/count.json", array(), 'GET');
                $webhook_count = json_decode($webhook_count['response'], JSON_PRETTY_PRINT);

                //  print_r($webhook_count);

                // $web = shopify_call($token, $host_shop, "/admin/api/2021-07/webhooks.json", array(), 'GET');
                // $web = json_decode($web['response'], JSON_PRETTY_PRINT);

                // // echo "<pre>";
                // // print_r($web);
                // // echo "</pre>";

                // foreach($web as $key => $web_val){
                //     foreach($web_val as $w_val){
                //         // echo "<pre>";
                //         // print_r($w_val['id']);
                //         // echo "</pre>";

                //         $webhook_delete = shopify_call($token, $host_shop, "/admin/api/2021-07/webhooks/". $w_val['id'] .".json", array(), 'DELETE');
                //         $webhook_delete = json_decode($webhook_delete['response'], JSON_PRETTY_PRINT);

                //         echo "<pre>";
                //         print_r($webhook_delete);
                //         echo "</pre>";



                //     }
                // }
                if ($webhook_count['count'] == 0) {
                    include_once("webhooks.php");
                }

                $webhook_count = shopify_call($token, $host_shop, "/admin/api/2021-07/webhooks/count.json", array(), 'GET');
                $webhook_count = json_decode($webhook_count['response'], JSON_PRETTY_PRINT);
                // echo "<br>Total WebHooks Counts : ";
                // print_r($webhook_count);
                // echo "<br>";

                include("get_products_json.php");
                ?>
            </div>
        </div>



        <div class="container products_block">
            <?php
            // $products_count = shopify_call($access_token, $host_shop, "/admin/api/2021-07/products/count.json", array(), 'GET');
            // $products_count = json_decode($products_count['response'], JSON_PRETTY_PRINT);
            ?>
            <!-- <div class="products">
                    <h3>Products</h3>
                    <button type="button" class="btn btn-outline-secondary position-relative">
                        Total
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?php // echo $products_count['count']; 
                            ?>
                            <span class="visually-hidden">unread messages</span>
                        </span>
                    </button>
                </div> -->
            <div>
                <?php
                // include_once("product_table.php");
                include_once("productDataUpdate.php");

                ?>

            </div>
            <div id="demo"></div>

        </div>


        <!-- </div> -->


        <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> -->

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script> -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

        <style>
            .products {
                display: flex;
                justify-content: space-between;
                align-items: center;
                align-content: center;
            }
            
            
        </style>
</body>

</html>