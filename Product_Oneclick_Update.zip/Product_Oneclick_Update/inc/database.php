<?php 

$host = 'localhost';
$port = '';
$dbname = 'promotionking_Product_Oneclick_UpdateDB';
$root = 'promotionking_ShopifyUser';
$pass = '^E[ybc*@G-kB';


$pdo = new PDO('mysql: host='. $host . ';port='. $port .';dbname='. $dbname .'', $root, $pass );
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Create database connection
$db = new mysqli($host, $root, $pass, $dbname);

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}