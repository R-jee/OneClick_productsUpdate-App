// document.getElementsByClassName('price-item--regular')[0].append('Hello');

var scriptFilename = "custom_script.js"; // don't forget to set the filename
var scriptUrl = (function () {
  if (document.currentScript) {
    // support defer & async (mozilla only)
    return document.currentScript.src;
  } else {
    var ls, s;
    var getSrc = function (ls, attr) {
      var i,
        l = ls.length,
        nf,
        s;
      for (i = 0; i < l; i++) {
        s = null;
        if (ls[i].getAttribute.length !== undefined) {
          s = ls[i].getAttribute(attr, 2);
        }
        if (!s) continue; // tag with no src
        nf = s;
        nf = nf.split("?")[0].split("/").pop(); // get script filename
        if (nf === scriptFilename) {
          return s;
        }
      }
    };
    ls = document.getElementsByTagName("script");
    s = getSrc(ls, "src");
    if (!s) {
      // search reference of script loaded by jQuery.getScript() in meta[name=srcipt][content=url]
      ls = document.getElementsByTagName("meta");
      s = getSrc(ls, "content");
    }
    if (s) return s;
  }
  return "";
})();

var shopPath = scriptUrl; //.substring(0, scriptUrl.lastIndexOf('/'))+"/";
var scriptPath = shopPath.substring(0, scriptUrl.lastIndexOf("/")) + "/";
shopPath = shopPath.split("?");
shopPath = shopPath[1];
shopPath = shopPath.split("=");
shopPath = shopPath[1];

////////////////////////////////////////////////////////////// print shopURL log
// console.log("Shop-Path: " + shopPath);
//////////////////////////////////////////////////////////////



// console.log(shopPath);
// console.log(getprice);
