<?php
require_once("inc/functions.php");
require_once("inc/database.php");

$ngrok_url = "https://promotionking.info";

// Set variables for our request
$shop = $_GET['shop'];
$api_key = "d0eb39d0981bcd60dd057737335650f5";
$scopes = "read_orders,write_orders,read_products,write_products,write_script_tags, read_themes,write_themes,read_content,write_content,read_product_listings,read_customers,write_customers,write_locales,write_locales,read_locations,read_inventory,write_inventory";
$redirect_uri = $ngrok_url . "/ShopifyApp/Product_Oneclick_Update/token.php";

// Build install/approval URL to redirect to
$install_url = "https://" . $shop . "/admin/oauth/authorize?client_id=" . $api_key . "&scope=" . $scopes . "&redirect_uri=" . urlencode($redirect_uri);

// Redirect
?>
<script>
    window.top.location.href = "<?php echo $install_url; ?>";
</script>
<?php
die();
