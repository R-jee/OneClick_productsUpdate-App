<?php
require_once("inc/functions.php");
require_once("inc/database.php");

$shop_host = $_POST['shop'];



$stmt = $pdo->prepare("SELECT * FROM `Request_formApp` WHERE shop_url=?  LIMIT 1 ");
$stmt->execute([$shop_host.'.myshopify.com']);
$user = $stmt->fetch();
//  print_r($user['access_token']);
$access_token = $user['access_token'];
$token = $access_token;
$data = $_POST['data'];

// $product_ids = $_POST['product_ids'];
// $Varients_ids = $_POST['Varients_ids'];

$Products_prices_array ;

// for($i = 0; $i> count($Varients_ids) ; $i++){
// }

// print_r($data[0]);

foreach ($data as $key => $value) {
    // print_r($value['price']);
    $array = array();
    if($value['price'] != $value['Price_hidden']){
        $array = array(
            "variant" => array(
                "id"      => $value['V_ID'],
                "price"   => $value['price']
            )
        );
        $prod_price_update = shopify_call($token, $shop_host, "/admin/api/2021-07/variants/". $value['V_ID'] .".json", $array, 'PUT');
        $prod_price_update = json_decode($prod_price_update['response'], JSON_PRETTY_PRINT);
    }

}


// echo json_encode(
//     array(
//         'sh' => $shop_host,
//         'tok' => $token,
//         'data' => $data,
//         'status' => "SUCCESS!"
//     )
// );
echo json_encode(
    array(
        'status' => "Successfully Updated!"
    )
);
die();


?>