<?php

$products = shopify_call($token, $host_shop, "/admin/api/2021-07/products.json", array(), 'GET');
$products = json_decode($products['response'], JSON_PRETTY_PRINT);
// print_r($products);

foreach ($products as $product) :
    foreach ($product as $key => $value) :
        // print_r($value['id']);

        $image_src_count = shopify_call($token, $host_shop, "GET /admin/api/2021-07/products/" . $value['id'] . "/images/count.json", array(), 'GET');
        // $image_src_count = json_decode($image_src_count['response'], JSON_PRETTY_PRINT);
        print_r($image_src_count);


        $image_src = shopify_call($token, $host_shop, "/admin/api/2021-07/products/" . $value['id'] . "/images.json", array(), 'GET');
        $image_src = json_decode($image_src['response'], JSON_PRETTY_PRINT);

        // print_r($image_src['images'][0]['src']);



?>
        <style>
            .card_products__ {
                position: relative;
                display: flex;
                flex-direction: column;
                min-width: 0;
                word-wrap: break-word;
                background-color: #fff;
                background-clip: border-box;
                border: 1px solid rgba(0, 0, 0, .125);
                border-radius: .25rem;
                transform: scale(0.9);
                transition: .5s ease-in-out;
                box-shadow: 0px 0px 0px 0px grey;
            }

            .card_products__:hover {
                transform: scale(1);
                box-shadow: 0px 2px 9px 0px grey;
            }
        </style>
        <div class="col-12 col-md-6 col-lg-4 mb-4 ">
            <div class="card border-primary mb-3 card_products__" style="width: 28rem;" product-id="<?php echo $value['id']; ?>">
                <!-- data-bs-toggle="modal" data-bs-target="#productsModal"> -->
                <img src="<?php

                            if (strpos($image_src['images'][0]['src'], "Notice") == "") {
                                echo $image_src['images'][0]['src'];
                            } else {
                                echo "https://dummyimage.com/600x400/b8b8b8/fff.jpg";
                            }
                            ?>" class="card-img-top img-fluid img-fluid-custom bg-light" alt="" >
                <div class="card-body border-top border-primary">
                    <p class="card-text"><?php echo  $value['title'] ?></p>
                </div>
            </div>
        </div>


<?php

    endforeach;
endforeach;

?>

<!-- Modal -->
<div class="modal fade" id="productsModal" tabindex="-1" aria-labelledby="productsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <form action="ajax.php" id="productForm">
                    <div class="form-floating m-3">
                        <input type="text" class="form-control" id="productTitle" name="productTitle" placeholder="Title" value="">
                        <label for="productTitle">Product Title</label>
                    </div>
                    <div class="form-floating m-3">
                        <textarea class="form-control" placeholder="Description" id="productDescription" name="productDescription" style="height: auto;"></textarea>
                        <!-- <label for="productDescription">Product Description</label> -->
                    </div>

                    <div class="form-floating m-3">
                        <select class="form-select" id="productCollection" name="productCollection" multiple>
                            <?php
                            $custom_collections = shopify_call($token, $host_shop, "/admin/api/2021-07/custom_collections.json", array('product_id' => $id), 'GET');
                            $custom_collections = json_decode($custom_collections['response'], JSON_PRETTY_PRINT);

                            foreach ($custom_collections as  $custom_collection) {
                                foreach ($custom_collection as $key => $value) {
                            ?>
                                    <option value="<?php echo $value['id']; ?>"><?php echo $value['title']; ?></option>
                                <?php
                                }
                            }

                            $smart_collections = shopify_call($token, $host_shop, "/admin/api/2021-07/smart_collections.json", array('product_id' => $id), 'GET');
                            $smart_collections = json_decode($smart_collections['response'], JSON_PRETTY_PRINT);
                            foreach ($smart_collections as  $smart_collection) {
                                foreach ($smart_collection as $key => $value) {
                                ?>
                                    <option value="<?php echo $value['id']; ?>"><?php echo $value['title']; ?></option>
                            <?php
                                }
                            }
                            ?>
                        </select>
                        <!-- <label for="productCollection">Product Collections</label> -->
                    </div>
                </form>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="SaveProduct" product-id=''>Save changes</button>
            </div>
        </div>
    </div>
</div>