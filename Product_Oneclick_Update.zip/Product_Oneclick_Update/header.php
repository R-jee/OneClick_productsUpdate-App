<?php

require_once("inc/functions.php");
require_once("inc/database.php");
header('Access-Control-Allow-Origin: *');
header('Content-Security-Policy: frame-ancestors https://*.myshopify.com/;');

$ngrok_url = "https://promotionking.info"; //  /ShopifyApp/Request_formApp
define('Domain_URL_', $ngrok_url . "/ShopifyApp/Product_Oneclick_Update");
// define('SHOPIFY_APP_SECRET', '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'); // Replace with your SECRET KEY

$api_key = "d0eb39d0981bcd60dd057737335650f5";

$requests = $_GET;
// echo print_r($requests);

$hmac = $requests['hmac'];
$serializeArray = serialize($requests);
$requests = array_diff_key($requests, array('hmac' => ''));
ksort($requests);

$url = parse_url('https://' . $requests['shop']);
$host = explode('.', $url['host']);

$host[0];
$host_shop = $host[0];
// echo $host_shop;
// echo $requests['shop'];   //  nimble-nws.myshopify.com
// header("Location: install.php?shop=". $requests['shop']);
// exit();

$shop = $requests['shop'];

// $statement = $pdo->prepare("SELECT * FROM `shopify_shop` WHERE `requests` = '". $url ."' LIMIT 1 ");
// $result = $statement->execute();

$stmt = $pdo->prepare("SELECT * FROM `Request_formApp` WHERE shop_url=?  LIMIT 1 ");
$stmt->execute([$shop]);
$user = $stmt->fetch();

//  print_r($user['access_token']);
$access_token = $user['access_token'];

if (empty($user)) {
    header("Location: install.php?shop=" . $requests['shop']);
    exit();
} else {
    //echo 'App';

    //$theme = shopify_call($token, $host_shop, "/admin/api/2021-07/themes.json", array() , 'GET');
    //print_r($theme);
    //$theme = json_decode($theme['response'], JSON_PRETTY_PRINT);


    $chkProduct = $db->query("SELECT * from Request_formApp WHERE shop_url='" .$shop . "' limit 1");
    if (mysqli_num_rows($chkProduct) == 0) {
        // update
        die("there is no access please reinstall discount app");
    }
    $result = mysqli_fetch_assoc($chkProduct);

    $token = $result['access_token']; //'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';
    //$api_endpoint = "/admin/themes.json";

    // print_r($theme);

    $script_tag_count = shopify_call($token, $host_shop, "/admin/api/2021-07/script_tags/count.json", array(), 'GET');
    $script_tag_count = json_decode($script_tag_count['response'], JSON_PRETTY_PRINT);
    //  print_r($script_tag);
    $script_tag = shopify_call($token, $host_shop, "/admin/api/2021-07/script_tags.json", array(), 'GET');
    $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
    // print_r($script_tag);
    if ($script_tag_count['count'] < 1) {
        $script_array = array(
            'script_tag' => array(
                'event' => 'onload',
                'src' => $ngrok_url . '/ShopifyApp/Product_Oneclick_Update/custom_script.js'
            )
        );
        $script_tag =  shopify_call($token,
            $host_shop,
            "/admin/api/2021-07/script_tags.json",
            $script_array,
            'POST'
        );
        $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
        $script_tag_id = $script_tag['script_tag']['id'];
        $statement = $pdo->prepare("UPDATE `Request_formApp` SET `script_tag_id`= '" . $script_tag_id . "'  WHERE `shop_url` = '" . $shop . "' ");
        $statement->execute();
    } else if ($script_tag_count['count'] == 1
    ) {
        $delete_script_tag =  shopify_call($token, $host_shop, "/admin/api/2021-07/script_tags/" . $script_tag['script_tags'][0]['id'] . ".json", array(), 'DELETE');
        $delete_script_tag = json_decode($delete_script_tag['response'], JSON_PRETTY_PRINT);
        $script_array = array(
            'script_tag' => array(
                'event' => 'onload',
                'src' => $ngrok_url . '/ShopifyApp/Product_Oneclick_Update/custom_script.js'
            )
        );
        $script_tag =  shopify_call($token,
            $host_shop,
            "/admin/api/2021-07/script_tags.json",
            $script_array,
            'POST'
        );
        $script_tag = json_decode($script_tag['response'], JSON_PRETTY_PRINT);
        $script_tag_id = $script_tag['script_tag']['id'];
        $statement = $pdo->prepare("UPDATE `Request_formApp` SET `script_tag_id`= '" . $script_tag_id . "'  WHERE `shop_url` = '" . $shop . "' ");
        $statement->execute();
    }
}
