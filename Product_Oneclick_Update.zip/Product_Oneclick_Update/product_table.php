<?php
// header('Access-Control-Allow-Origin: *');
// header('Content-Security-Policy: frame-ancestors *');

include('./inc/database.php');

$products = shopify_call($token, $host_shop, "/admin/api/2021-07/products.json", array(), 'GET');
$products = json_decode($products['response'], JSON_PRETTY_PRINT);
// print_r("<pre>");
// print_r( $products );
// print_r("</pre>");

?>

<div class=".table-responsive" style="overflow: auto; height:600px !important;">
    <table class="table table-hover">
        <thead style="background-color: #DC143C; color:white;" class="main-table-head">
            <tr class="main-table-heading__">
                <th scope="col"># </th>
                <th scope="col">ID</th>
                <th scope="col">Title</th>
                <th scope="col">Body HTML</th>
                <th scope="col">Vendor</th>
                <th scope="col">Product Type</th>
                <th scope="col">Created At</th>
                <th scope="col">Handle</th>
                <th scope="col">Updated At</th>
                <th scope="col">Published Date</th>
                <th scope="col">Template Suffix</th>
                <th scope="col">Published Scope</th>
                <th scope="col">Tags</th>
                <th scope="col">Admin GraphQL-api ID</th>
                <th scope="col">Variants</th>
                <th scope="col">Options</th>
                <th scope="col">Images</th>
                <th scope="col">Image</th>
            </tr>
        </thead>
        <tbody class="" id="all_product_table_body">
            <?php
            if (!empty($form_data['product_array_for_storing'])) {
                $product_array_for_storing__data = unserialize($form_data['product_array_for_storing']);
                $product_array_for_storing__data_array = array();
                foreach ($product_array_for_storing__data as $key => $val_arrdata) {
                    array_push($product_array_for_storing__data_array, $val_arrdata['val']);
                }
            }
            // print_r($product_array_for_storing__data_array);
            // array(
            //     'check_box_id' => '',
            //     'check_box_checked' => false,
            //     'id'     => '',
            //     'title'  => '',
            //     'handle' => '',
            //     'image'  => '',
            // );
            $product_array_for_storing = [];

            foreach ($products as $m_key => $product) :
                foreach ($product as $key => $value) :
                    // print_r((  $value ));

                    // echo '<br>';
            ?>
                    <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
                    <tr>
                        <th scope="row"><?php echo $key + 1; ?></th>
                        <td><?php echo $value['id']; ?></td>
                        <td><?php echo $value['title']; ?></td>
                        <td>
                            <div>
                                <div class="accordion accordion-flush" id="accordionFlush_bodyhtml_<?php echo $key + 1; ?>">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="accordionFlush-heading-<?php echo $key + 1; ?>">
                                            <button class="accordion-button collapsed btn btn-outline-info " type="button" data-bs-toggle="collapse" data-bs-target="#accordion-flush-collapse-<?php echo $key + 1; ?>" aria-expanded="false" aria-controls="accordion-flush-collapse-<?php echo $key + 1; ?>">
                                                Show/Hide
                                            </button>
                                        </h2>

                                        <div id="accordion-flush-collapse-<?php echo $key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionFlush-heading-<?php echo $key + 1; ?>" data-bs-parent="#accordionFlush_bodyhtml_<?php echo $key + 1; ?>">
                                            <div class="accordion-body"> <code><textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style="height: 200px;width:300px !important;"><?php echo $value['body_html']; ?></textarea></code> </div>
                                        </div>
                                    </div>

                                </div>
                            </div>


                        </td>
                        <td><?php echo $value['vendor']; ?></td>
                        <td><?php echo $value['product_type']; ?></td>
                        <td><?php echo $value['created_at']; ?></td>
                        <td><?php echo $value['handle']; ?></td>
                        <td><?php echo $value['updated_at']; ?></td>
                        <td><?php echo $value['published_at']; ?></td>
                        <td><?php echo $value['template_suffix']; ?></td>
                        <td><?php echo $value['published_scope']; ?></td>
                        <td><code><?php echo $value['tags']; ?></code></td>
                        <td><?php echo $value['admin_graphql_api_id']; ?></td>
                        <td><?php $Prod_variants = $value['variants'];  ?>
                            <div class="accordion accordion-flush" id="accordionFlush_variants_<?php echo $key + 1; ?>">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="accordionFlush-variants-heading-<?php echo $key + 1; ?>">
                                        <button class="accordion-button collapsed btn btn-outline-info " type="button" data-bs-toggle="collapse" data-bs-target="#accordion-flush-vatriants-collapse-<?php echo $key + 1; ?>" aria-expanded="false" aria-controls="accordion-flush-vatriants-collapse-<?php echo $key + 1; ?>">
                                            Show/Hide
                                        </button>
                                    </h2>

                                    <div id="accordion-flush-vatriants-collapse-<?php echo $key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionFlush-variants-heading-<?php echo $key + 1; ?>" data-bs-parent="#accordionFlush_variants_<?php echo $key + 1; ?>">
                                        <div class="accordion-body">
                                            <!-- //// -->
                                            <div id="accordion-flush-vatriants-collapse-<?php echo $key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionFlush-variants-heading-<?php echo $key + 1; ?>" data-bs-parent="#accordionFlush_variants_<?php echo $key + 1; ?>">
                                                <div class="accordion-body">
                                                    <div class="container wrap" style="overflow: auto; height:100%;">
                                                        <table class="table table-hover">
                                                            <thead style="background-color: #DC143C; color:white;" class="table-dark">
                                                                <tr>
                                                                    <th scope="col"># </th>
                                                                    <th scope="col">ID</th>
                                                                    <th scope="col">Product ID</th>
                                                                    <th scope="col">Title</th>
                                                                    <th scope="col">Price</th>
                                                                    <th scope="col">SKU</th>
                                                                    <th scope="col">Position</th>
                                                                    <th scope="col">Compare_at_price</th>
                                                                    <th scope="col">Fulfillment_service</th>
                                                                    <th scope="col">Inventory_management</th>
                                                                    <th scope="col">Option 1</th>
                                                                    <th scope="col">Option 2</th>
                                                                    <th scope="col">Option 3</th>
                                                                    <th scope="col">Created at</th>
                                                                    <th scope="col">Updated at</th>
                                                                    <th scope="col">Taxable</th>
                                                                    <th scope="col">Barcode</th>
                                                                    <th scope="col">Grams</th>
                                                                    <th scope="col">Image_id</th>
                                                                    <th scope="col">Weight</th>
                                                                    <th scope="col">Weight_unit</th>
                                                                    <th scope="col">Inventory_item_id</th>
                                                                    <th scope="col">Inventory_quantity</th>
                                                                    <th scope="col">Old_inventory_quantity</th>
                                                                    <th scope="col">Presentment_prices</th>
                                                                    <th scope="col">Requires_shipping</th>
                                                                    <th scope="col">Admin_graphql_api_id</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="" id="all_product_variants_table_body">
                                                                <?php
                                                                foreach ($Prod_variants as $variant_value_key => $variant_value) {
                                                                ?>
                                                                    <tr>
                                                                        <td><?php echo $variant_value_key + 1; ?></td>
                                                                        <td><?php echo $variant_value['id']; ?></td>
                                                                        <td><?php echo $variant_value['product_id']; ?></td>
                                                                        <td><?php echo $variant_value['title']; ?></td>
                                                                        <td><?php echo $variant_value['price']; ?></td>
                                                                        <td><?php echo $variant_value['sku']; ?></td>
                                                                        <td><?php echo $variant_value['position']; ?></td>
                                                                        <td><?php print_r($variant_value['inventory_policy']); ?></td>
                                                                        <td><?php echo $variant_value['compare_at_price']; ?></td>
                                                                        <td><?php echo $variant_value['fulfillment_managment']; ?></td>
                                                                        <td><?php echo $variant_value['option1']; ?></td>
                                                                        <td><?php echo $variant_value['option2']; ?></td>
                                                                        <td><?php echo $variant_value['option3']; ?></td>
                                                                        <td><?php echo $variant_value['created_at']; ?></td>
                                                                        <td><?php echo $variant_value['updated_at']; ?></td>
                                                                        <td><input class="form-check-input" type="checkbox" value="<?php echo $variant_value['taxable']; ?>" id="flexCheckDefault-taxable" <?php if ($variant_value['taxable'] == true) {
                                                                                                                                                                                                                echo "checked";
                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                echo "";
                                                                                                                                                                                                            }  ?>></td>
                                                                        <td><?php echo $variant_value['barcode']; ?></td>
                                                                        <td><?php echo $variant_value['grams']; ?></td>
                                                                        <td><?php echo $variant_value['image_id']; ?></td>
                                                                        <td><?php echo $variant_value['weight']; ?></td>
                                                                        <td><?php echo $variant_value['weight_unit']; ?></td>
                                                                        <td><?php echo $variant_value['inventory_item_id']; ?></td>
                                                                        <td><?php echo $variant_value['inventory_quantity']; ?></td>
                                                                        <td><?php echo $variant_value['old_inventory_quantity']; ?></td>
                                                                        <td><?php print_r($variant_value['presentment_prices']['price']); ?></td>
                                                                        <td><input class="form-check-input" type="checkbox" value="<?php echo $variant_value['requires_shipping']; ?>" id="flexCheckDefault-requires_shipping" <?php if ($variant_value['requires_shipping'] == true) {
                                                                                                                                                                                                                                    echo "checked";
                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                    echo "";
                                                                                                                                                                                                                                }  ?>></td>
                                                                        <td><?php echo $variant_value['admin_graphql_api_id']; ?></td>
                                                                    </tr>
                                                                <?php

                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- //// -->
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </td>
                        <td>
                            <?php
                            foreach ($value['options'] as $option_key => $options) {
                                // print_r($options['name'].'<br>');
                            ?>
                                <div>
                                    <div class="accordion accordion-flush" id="accordionFlush_opyions_<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>">
                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="accordionopyions-heading-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>">
                                                <button class="accordion-button collapsed btn btn-outline-info " type="button" data-bs-toggle="collapse" data-bs-target="#accordion-opyions-collapse-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>" aria-expanded="false" aria-controls="accordion-opyions-collapse-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>">
                                                    <?php echo $options['name']; ?>
                                                </button>
                                            </h2>

                                            <div id="accordion-opyions-collapse-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionopyions-heading-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>" data-bs-parent="#accordionFlush_opyions_<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>">
                                                <div class="accordion-body">
                                                    <div class="container " style="overflow: auto; height:100%;">
                                                        <table class="table table-sm    table-hover">
                                                            <thead style="background-color: #DC143C; color:white;" class="table-dark">
                                                                <tr>
                                                                    <th scope="col">ID</th>
                                                                    <th scope="col">PRODUCT ID</th>
                                                                    <th scope="col">Name</th>
                                                                    <th scope="col">POSITION</th>
                                                                    <th scope="col">VALUES</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="" id="all_options_table_body">
                                                                <td><?php echo $options['id']; ?></td>
                                                                <td><?php echo $options['product_id']; ?></td>
                                                                <td><?php echo $options['name']; ?></td>
                                                                <td><?php echo $options['position']; ?></td>
                                                                <td>

                                                                    <div>
                                                                        <div class="accordion accordion-flush" id="accordionFlush_options_value_<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>">
                                                                            <div class="accordion-item">
                                                                                <h2 class="accordion-header" id="accordionFlush-options-values-heading-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>">
                                                                                    <button class="accordion-button collapsed btn btn-outline-info " type="button" data-bs-toggle="collapse" data-bs-target="#accordion-flush-options-values-collapse-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>" aria-expanded="false" aria-controls="accordion-flush-options-values-collapse-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>">
                                                                                        Show/Hide
                                                                                    </button>
                                                                                </h2>

                                                                                <div id="accordion-flush-options-values-collapse-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionFlush-options-values-heading-<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>" data-bs-parent="#accordionFlush_options_value_<?php echo $key + 1; ?>_<?php echo $option_key + 1; ?>">
                                                                                    <?php
                                                                                    // echo $options['values']; 
                                                                                    foreach ($options['values'] as $options_values_key => $options_values) {
                                                                                        // print_r($options_values);
                                                                                    ?>
                                                                                        <div class="accordion-body"> <code><?php echo $options_values; ?></code> </div>
                                                                                    <?php
                                                                                    }
                                                                                    ?>
                                                                                </div>
                                                                            </div>

                                                                        </div>
                                                                    </div>

                                                                </td>

                                                            </tbody>
                                                        </table>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            }
                            ?>
                        </td>
                        <td>
                            <div>
                                <div class="accordion accordion-flush" id="accordionFlush_images_<?php echo $key + 1; ?>">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="accordionFlush-heading-images-<?php echo $key + 1; ?>">
                                            <button class="accordion-button collapsed btn btn-outline-info " type="button" data-bs-toggle="collapse" data-bs-target="#accordion-flush-collapse-images-<?php echo $key + 1; ?>" aria-expanded="false" aria-controls="accordion-flush-collapse-images-<?php echo $key + 1; ?>">
                                                Show/Hide
                                            </button>
                                        </h2>

                                        <div id="accordion-flush-collapse-images-<?php echo $key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionFlush-heading-images-<?php echo $key + 1; ?>" data-bs-parent="#accordionFlush_images_<?php echo $key + 1; ?>">
                                            <div class="accordion-body">

                                                <div class="container wrap" style="overflow: auto; height:100%;">
                                                    <table class="table table-hover">
                                                        <thead style="background-color: #DC143C; color:white;" class="table-dark">
                                                            <tr>
                                                                <th scope="col"># </th>
                                                                <th scope="col">ID</th>
                                                                <th scope="col">Product ID</th>
                                                                <th scope="col">Position</th>
                                                                <th scope="col">Created at</th>
                                                                <th scope="col">Updated at</th>
                                                                <th scope="col">Alt</th>
                                                                <th scope="col">Width</th>
                                                                <th scope="col">Height</th>
                                                                <th scope="col">src</th>
                                                                <th scope="col">Variant_id</th>
                                                                <th scope="col">Admin_graphql_api_id</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="" id="all_product_images_table_body">
                                                            <?php

                                                            foreach ($value['images'] as $image_key => $image_value) {
                                                            ?>
                                                                <tr>
                                                                    <td><?php echo $image_key + 1; ?></td>
                                                                    <td><?php echo $image_value['id']; ?></td>
                                                                    <td><?php echo $image_value['product_id']; ?></td>
                                                                    <td><?php echo $image_value['position']; ?></td>
                                                                    <td><?php echo $image_value['created_at']; ?></td>
                                                                    <td><?php echo $image_value['updated_at']; ?></td>
                                                                    <td><?php echo $image_value['alt']; ?></td>
                                                                    <td><?php echo $image_value['width']; ?></td>
                                                                    <td><?php echo $image_value['height']; ?></td>
                                                                    <td><img src="<?php echo $image_value['src']; ?>" class="thumbnail_image" height="30" width="30" /></td>
                                                                    <td><?php echo $image_value['variant_ids']; ?></td>
                                                                    <td><?php echo $image_value['admin_graphql_api_id']; ?></td>
                                                                </tr>
                                                            <?php
                                                            }

                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>

                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </td>
                        <td>
                            <div>
                                <div class="accordion accordion-flush" id="accordionFlush_image_<?php echo $key + 1; ?>">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="accordionFlush-heading-image-<?php echo $key + 1; ?>">
                                            <button class="accordion-button collapsed btn btn-outline-info " type="button" data-bs-toggle="collapse" data-bs-target="#accordion-flush-collapse-image-<?php echo $key + 1; ?>" aria-expanded="false" aria-controls="accordion-flush-collapse-image-<?php echo $key + 1; ?>">
                                                Show/Hide
                                            </button>
                                        </h2>

                                        <div id="accordion-flush-collapse-image-<?php echo $key + 1; ?>" class="accordion-collapse collapse" aria-labelledby="accordionFlush-heading-image-<?php echo $key + 1; ?>" data-bs-parent="#accordionFlush_image_<?php echo $key + 1; ?>">
                                            <div class="accordion-body">

                                                <div class="container wrap" style="overflow: auto; height:100%;">
                                                    <table class="table table-hover">
                                                        <thead style="background-color: #DC143C; color:white;" class="table-dark">
                                                            <tr>
                                                                
                                                                <th scope="col">ID</th>
                                                                <th scope="col">Product ID</th>
                                                                <th scope="col">Position</th>
                                                                <th scope="col">Created at</th>
                                                                <th scope="col">Updated at</th>
                                                                <th scope="col">Alt</th>
                                                                <th scope="col">Width</th>
                                                                <th scope="col">Height</th>
                                                                <th scope="col">src</th>
                                                                <th scope="col">Variant_id</th>
                                                                <th scope="col">Admin_graphql_api_id</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="" id="all_product_image_table_body">
                                                            <?php
                                                            $image_value = $value['image'];
                                                            ?>
                                                                <tr>
                                                                    <td><?php echo $image_value['id']; ?></td>
                                                                    <td><?php echo $image_value['product_id']; ?></td>
                                                                    <td><?php echo $image_value['position']; ?></td>
                                                                    <td><?php echo $image_value['created_at']; ?></td>
                                                                    <td><?php echo $image_value['updated_at']; ?></td>
                                                                    <td><?php echo $image_value['alt']; ?></td>
                                                                    <td><?php echo $image_value['width']; ?></td>
                                                                    <td><?php echo $image_value['height']; ?></td>
                                                                    <td><img src="<?php echo $image_value['src']; ?>" class="thumbnail_image" height="30" width="30" /></td>
                                                                    <td>
                                                                        <?php 
                                                                            foreach ($image_value['variant_ids'] as $img_variant_ids_key => $img_variant_ids) {
                                                                                ?>
                                                                                    <code><?php echo $img_variant_ids; ?></code><br>
                                                                                <?php
                                                                            }
                                                                        ?>
                                                                    </td>
                                                                    <td><?php echo $image_value['admin_graphql_api_id']; ?></td>
                                                                </tr>
                                                            
                                                        </tbody>
                                                    </table>
                                                </div>

                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>

                        </td>

                        <!-- 
                        
                        <td>
                        <?php /* 
                        print_r(($value['variants'][0])['price']); ?></td>
                        <?php
                        $images = shopify_call($token, $host_shop, "/admin/api/2021-04/products/" . $value['id'] . "/images.json", array(), 'GET');
                        $images = json_decode($images['response'], JSON_PRETTY_PRINT);
                        //  print_r($images);
                        ?>
                        <td><img src="<?php if($images['images'][0]['src'] != null){echo $images['images'][0]['src'];} else{echo "https://dummyimage.com/600x400/ebe4eb/a86d8e";} ?>" style="width: 30px; height:30px;" class="img-fluid" alt="<?php echo $value['handle'];  
                        */
                        ?>"></td>
                     -->

                    </tr>
            <?php
                    array_push(
                        $product_array_for_storing,
                        array(
                            'check_box_id' => "discount_app_products" . ($key + 1),
                            'id'     => $value['id'],
                        )
                    );
                endforeach;
            endforeach;

            ?>
        </tbody>
    </table>
    <style>
        tr.main-table-heading__ {
            font-size: 12px;
            padding: 3px 3px;
            padding-bottom: 0px;
        }

        thead.main-table-head {
            vertical-align: center;
            white-space: nowrap;
        }

        tbody#all_product_table_body {
            font-size: 12px;
            white-space: nowrap;
            text-align: inherit;
        }

        button.accordion-button.btn.btn-outline-info.collapsed {
            padding: 2px 11px;
            margin: 0px 0px;
            border: 1px solid gray !important;
            border-radius: 3px !important;
            font-size: 12px;
        }

        button.accordion-button.btn.btn-outline-info {
            padding: 2px 6px;
            font-size: 12px;
        }

        .accordion-body {
            padding: 0.5rem 0.5rem;
        }


        .thumbnail_image {
            transition: 0.5s ease-in-out;
        }

        .thumbnail_image:hover {
            position: relative;
            width: 120px;
            height: auto;
            display: block;
            z-index: 999;

        }
    </style>
</div>